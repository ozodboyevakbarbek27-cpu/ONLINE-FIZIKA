# Online fizika — Telegram Mini App

Darslar, testlar va ustoz xonasi (ustoz o'ynamaydi, faqat natijani jonli ko'radi).

## 1. Tayyorlash
1. @BotFather da botingiz tokenini oling (bor bo'lsa, o'shani ishlating).
2. Telegram ID ingizni @userinfobot dan bilib oling — bu ustoz ID si.

## 2. Joylash (https shart)
Render.com / Railway.app / VPS:
- Bu papkani GitHub ga yuklang → Render da "New Web Service" tanlang.
- Build: `npm install`  |  Start: `npm start`
- Environment o'zgaruvchilari: `.env.example` dagi BOT_TOKEN, WEBAPP_URL, TEACHER_IDS
- Deploy bo'lgach, bergan https manzilni WEBAPP_URL ga yozing va qayta ishga tushiring.

Bot allaqachon boshqa joyda ishlayotgan bo'lsa: `BOT_POLL=0` qo'ying, @BotFather → /setmenubutton orqali WEBAPP_URL ni ulang.

## 3. Ishlatish
- Ustoz: botni ochadi → "Xona ochish" → mavzu/vaqtni tanlaydi → 6 xonali kodni o'quvchilarga aytadi → "Boshlash".
- O'quvchi: "Online o'yinga kirish" → kodni kiritadi.
- Tezroq to'g'ri javob = ko'proq ball (500–1000).

## 4. Savol qo'shish
`data/topics.json` ichida yangi mavzu yoki savol qo'shing:
`{"q":"Savol","o":["A","B","C","D"],"a":0,"e":"Izoh"}`  (a — to'g'ri variant raqami, 0 dan boshlanadi; variantlar aynan 4 ta bo'lsin)

## Kompyuterda sinash
`.env` da DEV=1 qiling, `npm install && npm run dev`, brauzerda `http://localhost:3000/?id=1` (ustoz) va boshqa oynada `?id=2` (o'quvchi). Ustoz ID si TEACHER_IDS da 1 bo'lsin.
